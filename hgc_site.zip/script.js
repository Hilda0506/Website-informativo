// Dark/Light Mode
function toggleMode(){
  document.body.classList.toggle("dark");
}

// Multi idioma (placeholder)
let lang = "es";
function toggleLang(){
  lang = (lang === "es") ? "en" : "es";
  document.documentElement.lang = lang;
  alert(lang === "es" ? "Idioma cambiado a Español" : "Language switched to English");
}

// Año dinámico
document.addEventListener("DOMContentLoaded", ()=>{
  let yearSpan = document.getElementById("year");
  if(yearSpan) yearSpan.textContent = new Date().getFullYear();
});
